﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*
 * STUDENT NAME: 
 * STUDENT ID:
 * DESCRIPTION: This is the Power Class
 */

namespace COMP123_S2019_FinalTestA.Objects
{
    public class Power
    {
        // Public Properties
        public string Name { get; set; }
        public int Number { get; set; }
    }
}
