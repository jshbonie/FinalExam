﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using COMP123_S2019_FinalTestA.Objects;
using COMP123_S2019_FinalTestA.Views;

/*
 * STUDENT NAME: Joshua Bonie
 * STUDENT ID: 301009614
 * DESCRIPTION: This is the Here Generator Form
 */

namespace COMP123_S2019_FinalTestA.Views
{
   
    public partial class HeroGenerator : COMP123_S2019_FinalTestA.Views.MasterForm
    {
        List<string> PowersList = new List<string>();
        List<string> FirstNameList = new List<string>();
        List<string> LastNameList = new List<string>();

        Random random = new Random();
        public HeroGenerator()
        {
            InitializeComponent();
        }

        /// <summary>
        /// This is the event handler for the BackButton Click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BackButton_Click(object sender, EventArgs e)
        {
            if (MainTabControl.SelectedIndex != 0)
            {
                MainTabControl.SelectedIndex--;
            }
        }

        /// <summary>
        /// This is the event handler for the NextButton Click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NextButton_Click(object sender, EventArgs e)
        {
           // Program.hero.FirstName = FirstNameDataLabel.Text;
            Program.hero.LastName = LastNameDataLabel.Text;
            Program.hero.HeroName = HeroNameTextBox.Text;

            if (MainTabControl.SelectedIndex < MainTabControl.TabPages.Count - 1)
            {
                MainTabControl.SelectedIndex++;
            }
           
        }

        #region Created Methods
        /// <summary>
        /// Methods made to be used by buttons, load etc
        /// </summary>
        public void GenerateNames()
        {
            //Inputing First Name
            int index = random.Next(FirstNameList.Count);
            FirstNameDataLabel.Text = FirstNameList[index];


            //Inputing Last Name
            int index2 = random.Next(LastNameList.Count);
            LastNameDataLabel.Text = LastNameList[index2];
        }

        /// <summary>
        /// Load Name from file
        /// </summary>
        public void LoadNames()
        {

            string fileFnamePath = @"C:..\..\Data\firstNames.txt";
            string fileLnamePath = @"C:..\..\Data\lastNames.txt";
            FirstNameList = File.ReadAllLines(fileFnamePath).ToList();
            LastNameList = File.ReadAllLines(fileLnamePath).ToList();

        }
        /// <summary>
        /// Load abilities from file
        /// </summary>

        public void LoadAbilities()
        {
            FightingDataLabel.Text = random.Next(10, 50).ToString();
            AgilityDataLabel.Text = random.Next(10, 50).ToString();
            StrengthDataLabel.Text = random.Next(10, 50).ToString();
            EnduranceDataLabel.Text = random.Next(10, 50).ToString();
            ReasonDataLabel.Text = random.Next(10, 50).ToString();
            IntuitionDataLabel.Text = random.Next(10, 50).ToString();
            PsycheDataLabel.Text = random.Next(10, 50).ToString();
            PopularityDataLabel.Text = random.Next(10, 50).ToString();
        }

        /// <summary>
        /// load powers from file
        /// </summary>
        public void LoadPowers()
        {
            string filePowerPath = @"C:..\..\Data\powers.txt";
            PowersList = File.ReadAllLines(filePowerPath).ToList();
        }

        /// <summary>
        /// generate randome powers
        /// </summary>
        public void GeneratePowers()
        {
            int index = random.Next(PowersList.Count);
            Power1DataLabel.Text = PowersList[index];
            index = random.Next(PowersList.Count);
            Power2DataLabel.Text = PowersList[index];
            index = random.Next(PowersList.Count);
            Power3DataLabel.Text = PowersList[index];
            index = random.Next(PowersList.Count);
            Power4DataLabel.Text = PowersList[index];
        }

        /// <summary>
        /// load character info to textbox
        /// </summary>
        public void LoadCharacterInfo()
        {
            heroNameSheet.Text = Program.hero.HeroName;
            FnameSheet.Text = Program.hero.FirstName;
            lnameSheet.Text = Program.hero.LastName;
            strengthsheet.Text = Program.hero.Strength;
            fightingSheet.Text = Program.hero.Fighting;
            agilitySheet.Text = Program.hero.Agility;
            enduranceSheet.Text = Program.hero.Endurance;
            reasonSheet.Text = Program.hero.Reason;
            intuitionsheet.Text = Program.hero.Intuition;
            psycheSheet.Text = Program.hero.Psyche;
            popularitySheet.Text = Program.hero.Popularity;
            
            
        }
        #endregion

        /// <summary>
        /// Does everything when form loads
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HeroGenerator_Load(object sender, EventArgs e)
        {
            LoadNames();
            GenerateNames();
            LoadAbilities();
            LoadPowers();
            if (MainTabControl.SelectedIndex == 3)
            {
                LoadCharacterInfo();
            }
        }

        /// <summary>
        /// Generate random name
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GenerateNameButton_Click(object sender, EventArgs e)
        {
            GenerateNames();
        }

        /// <summary>
        /// Generate random abilities
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GenerateAbilitiesButton_Click(object sender, EventArgs e)
        {
            LoadAbilities();
        }

        /// <summary>
        /// next button on form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NextButtonAbilities_Click(object sender, EventArgs e)
        {
            if (MainTabControl.SelectedIndex < MainTabControl.TabPages.Count - 1)
            {
                MainTabControl.SelectedIndex++;
            }

            Program.hero.Fighting = FightingDataLabel.Text;
            Program.hero.Agility = AgilityDataLabel.Text;
            Program.hero.Strength = StrengthDataLabel.Text;
            Program.hero.Endurance = EnduranceDataLabel.Text;
            Program.hero.Reason = ReasonDataLabel.Text;
            Program.hero.Intuition = IntuitionDataLabel.Text;
            Program.hero.Psyche = PsycheDataLabel.Text;
            Program.hero.Popularity = PopularityDataLabel.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GeneratePowers();

        }

        private void HeroGenerator_Activated(object sender, EventArgs e)
        {
            
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program.aboutForm.ShowDialog();
        }

        /// <summary>
        /// allow user to open file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //confgure the dile dialog

            openFileDialog1.FileName = "Product.txt";

            openFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();

            openFileDialog1.Filter = "Text Files (*.txt)|*.txt| All Files (*.*)|*.*";



            //open the file diolog

            var result = openFileDialog1.ShowDialog();

            if (result != DialogResult.Cancel)
            {



                try

                {

                    //open file stream to read

                    using (StreamReader inputStream = new StreamReader(File.Open(openFileDialog1.FileName, FileMode.Open)))

                    {

                        // read stuff from the file

                        Program.hero.HeroName = inputStream.ReadLine();
                        Program.hero.FirstName = inputStream.ReadLine();
                        Program.hero.LastName = inputStream.ReadLine();
                        Program.hero.Strength = inputStream.ReadLine();


                        //cleanup

                        inputStream.Close();

                        inputStream.Dispose();

                    }



                    



                }

                catch (IOException exception)

                {

                    Debug.WriteLine("ERROR " + exception.Message);



                    MessageBox.Show("ERROR " + exception.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }



            }
        }

        /// <summary>
        /// allow user to save info to file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            //confgure the dile dialog

            openFileDialog1.FileName = "Product.txt";

            openFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();

            openFileDialog1.Filter = "Text Files (*.txt)|*.txt| All Files (*.*)|*.*";



            //open the file diolog

            var result = openFileDialog1.ShowDialog();

            if (result != DialogResult.Cancel)

            {

                // open a stream to write

                using (StreamWriter outputString = new StreamWriter(File.Open(openFileDialog1.FileName, FileMode.Create)))

                {



                    // write stuff to the file

                    outputString.WriteLine(Program.hero.HeroName);
                    outputString.WriteLine(Program.hero.FirstName);
                    outputString.WriteLine(Program.hero.LastName);
                    outputString.WriteLine(Program.hero.Strength);
                    outputString.WriteLine(Program.hero.Agility);
                    outputString.WriteLine(Program.hero.Endurance);

                    // close file

                    outputString.Close();

                    outputString.Dispose();



                    //message alerting user the file has been saved

                    MessageBox.Show("File Saved...", "Saving file...", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }

            }


        }
    }
}
